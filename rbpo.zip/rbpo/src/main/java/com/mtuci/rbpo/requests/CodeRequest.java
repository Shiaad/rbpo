package com.mtuci.rbpo.requests;

import lombok.Data;

@Data
public class CodeRequest {
    String code;
}
